function getValueById(id) {
    element = document.getElementById(id);
    elementValue = element.value;
    element.value = '';
    return elementValue;
}

function btnHandler() {
    const examListContainer = document.getElementById('exam-list');
    const exam = getValueById('exam-name');
    const institution = getValueById('inst-name');
    const gpa = getValueById('gpa');
    const year = getValueById('year');
    if(exam === '' || institution === '' || gpa === '' || year === ''){
        alert('Fields cannot be empty');
        return;
    }
    const listTr = document.createElement('tr');
    listTr.innerHTML = `
        <td>${exam}</td>
        <td>${institution}</td>
        <td>${gpa}</td>
        <td>${year}</td>
    `;
    examListContainer.appendChild(listTr);
}